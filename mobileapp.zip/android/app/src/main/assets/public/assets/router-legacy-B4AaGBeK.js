System.register(["./react-legacy-B1-f77hp.js"],function(e,t){"use strict";return{setters:[null],execute:function(){}}});
