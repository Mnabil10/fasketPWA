export const FASKET_CONFIG = {
  serviceArea: "We deliver anywhere inside Badr City",
  cityCoverage: "All districts of Badr City, Cairo",
  workingHours: "Daily from 9:00 AM to 1:00 AM",
  websiteUrl: "https://fasket.shop",
  webAppUrl: "https://fasket.shop/app",
  supportEmail: "info@fasket.com",
  supportPhone: "+201200000000",
  whatsappNumber: "+201200000000",
  playStoreUrl: "https://play.google.com/store/apps/details?id=customer.fasket.cloud",
  appStoreUrl: "",
};
