import React, { useEffect, useMemo, useRef, useState } from "react";
import { useTranslation } from "react-i18next";
import { Button } from "../../ui/button";
import { Input } from "../../ui/input";
import { Textarea } from "../../ui/textarea";
import { Badge } from "../../ui/badge";
import { Skeleton } from "../../ui/skeleton";
import { Label } from "../../ui/label";
import { AlertTriangle, ArrowLeft, MapPin, Plus, Clock, Truck, DollarSign } from "lucide-react";
import { AppState, type UpdateAppState } from "../CustomerApp";
import { ImageWithFallback } from "../../figma/ImageWithFallback";
import { useToast } from "../providers/ToastProvider";
import { useAddresses, useCart, useNetworkStatus, useApiErrorToast } from "../hooks";
import { placeGuestOrder, placeOrder, quoteGuestOrder, type GuestOrderQuote } from "../../services/orders";
import { fmtEGP, fromCents } from "../../lib/money";
import type { Address, OrderDetail, OrderGroupSummary } from "../../types/api";
import { NetworkBanner, EmptyState, RetryBlock, LocationPicker } from "../components";
import { trackCheckoutStarted, trackOrderFailed, trackOrderPlaced } from "../../lib/analytics";
import { goToCart } from "../navigation/navigation";
import { mapApiErrorToMessage } from "../../utils/mapApiErrorToMessage";
import { extractNoticeMessage } from "../../utils/extractNoticeMessage";
import { useDebouncedValue } from "../../hooks/useDebouncedValue";
import { isFeatureEnabled } from "../utils/mobileAppConfig";

interface CheckoutScreenProps {
  appState: AppState;
  updateAppState: UpdateAppState;
}

export function CheckoutScreen({ appState, updateAppState }: CheckoutScreenProps) {
  const { t, i18n } = useTranslation();
  const { showToast } = useToast();
  const isGuest = !appState.user;
  const guestCheckoutEnabled = isFeatureEnabled(appState.settings?.mobileApp, "guestCheckout", true);
  const [selectedAddressId, setSelectedAddressId] = useState<string | null>(null);
  const [loyaltyToRedeem, setLoyaltyToRedeem] = useState(0);
  const cart = useCart({ userId: appState.user?.id, addressId: selectedAddressId });
  const { isOffline } = useNetworkStatus();
  const apiErrorToast = useApiErrorToast();
  const {
    addresses,
    isLoading: addressesLoading,
    isError: addressesError,
    error: addressesErrorObj,
    refetch: refetchAddresses,
  } = useAddresses({ enabled: !isGuest });

  const guestSession = appState.guestSession;
  const [guestName, setGuestName] = useState(guestSession?.name ?? "");
  const [guestPhone, setGuestPhone] = useState(guestSession?.phone ?? "");
  const [guestAddress, setGuestAddress] = useState(guestSession?.address?.fullAddress ?? "");
  const [guestLatInput, setGuestLatInput] = useState(
    guestSession?.address?.lat != null ? String(guestSession.address.lat) : ""
  );
  const [guestLngInput, setGuestLngInput] = useState(
    guestSession?.address?.lng != null ? String(guestSession.address.lng) : ""
  );
  const [guestAddressNotes, setGuestAddressNotes] = useState(guestSession?.address?.notes ?? "");
  const [guestQuote, setGuestQuote] = useState<GuestOrderQuote | null>(null);
  const [guestQuoteError, setGuestQuoteError] = useState<string | null>(null);
  const [guestQuoteLoading, setGuestQuoteLoading] = useState(false);
  const guestQuoteRef = useRef(0);

  const [deliveryNotes, setDeliveryNotes] = useState("");
  const [saving, setSaving] = useState(false);
  const [couponInput, setCouponInput] = useState("");
  const [couponFeedback, setCouponFeedback] = useState<{ type: "success" | "error"; message: string } | null>(null);
  const idempotencyKeyRef = useRef<string | null>(null);
  const savingRef = useRef(false);
  const [deliveryTermsAccepted, setDeliveryTermsAccepted] = useState(false);

  const parseCoordinate = (value: string) => {
    const trimmed = value.trim();
    if (!trimmed) return null;
    const num = Number(trimmed);
    return Number.isFinite(num) ? num : null;
  };

  const loading = cart.isLoading || cart.isFetching || (!isGuest && addressesLoading);
  const hasError = cart.isError || (!isGuest && addressesError);
  const combinedError = cart.error || addressesErrorObj;
  const errorMessage = hasError ? mapApiErrorToMessage(combinedError, "checkout.messages.loadError") : "";

  const serverCart = cart.rawCart;
  const previewItems = cart.items;
  const distancePricingEnabled = appState.settings?.delivery?.distancePricingEnabled ?? true;
  const guestLat = parseCoordinate(guestLatInput);
  const guestLng = parseCoordinate(guestLngInput);
  const guestLocationValid = !distancePricingEnabled || (guestLat != null && guestLng != null);
  const guestAddressValid = guestAddress.trim().length > 0;
  const guestLocationValue = useMemo(
    () => (guestLat != null && guestLng != null ? { lat: guestLat, lng: guestLng } : null),
    [guestLat, guestLng]
  );
  const handleGuestLocationPick = (value: { lat: number; lng: number }) => {
    setGuestLatInput(value.lat.toFixed(6));
    setGuestLngInput(value.lng.toFixed(6));
  };

  const guestItems = useMemo(
    () =>
      previewItems.map((item) => ({
        productId: item.productId,
        qty: item.quantity,
        branchId: item.branchId ?? item.product?.branchId ?? null,
      })),
    [previewItems]
  );

  const cartGroups = isGuest ? guestQuote?.groups ?? [] : serverCart?.groups ?? [];
  const subtotalCents = isGuest ? guestQuote?.subtotalCents ?? cart.subtotalCents : cart.subtotalCents;
  const shippingFeeCents = isGuest ? guestQuote?.shippingFeeCents ?? 0 : cart.shippingFeeCents;
  const serviceFeeCents = isGuest ? guestQuote?.serviceFeeCents ?? 0 : cart.serviceFeeCents;
  const discountCents = isGuest ? 0 : cart.discountCents;
  const loyaltyDiscountCents = isGuest ? 0 : cart.loyaltyDiscountCents;
  const subtotal = fromCents(subtotalCents);
  const shippingFee = fromCents(shippingFeeCents);
  const serviceFee = fromCents(serviceFeeCents);
  const couponDiscount = fromCents(discountCents);
  const loyaltyDiscount = fromCents(loyaltyDiscountCents);
  const cartId = serverCart?.cartId ?? null;
  const estimatedDeliveryMinutes = isGuest
    ? appState.settings?.delivery?.defaultEtaMinutes ?? undefined
    : cart.deliveryEstimateMinutes ?? undefined;
  const loyaltyBalance = appState.user?.loyaltyPoints ?? appState.user?.points ?? 0;
  const maxRedeemablePoints = Math.min(loyaltyBalance, cart.loyaltyMaxRedeemablePoints || loyaltyBalance);
  const loyaltySettings = appState.settings?.loyalty;
  const redeemRate = loyaltySettings?.redeemRate && loyaltySettings.redeemRate > 0 ? loyaltySettings.redeemRate : 100;
  const previewRedeemValue = loyaltyToRedeem > 0 ? loyaltyToRedeem / redeemRate : 0;
  const total = Math.max(
    0,
    subtotal + shippingFee + serviceFee - couponDiscount - loyaltyDiscount - previewRedeemValue
  );
  const appliedCoupon = cart.couponCode;
  const couponsEnabled = isFeatureEnabled(appState.settings?.mobileApp, "coupons", true);
  const loyaltyFeatureEnabled = isFeatureEnabled(appState.settings?.mobileApp, "loyalty", true);
  const loyaltyEnabled = !isGuest && Boolean(loyaltySettings?.enabled && loyaltyFeatureEnabled && maxRedeemablePoints > 0);
  const deliveryRequiresLocation = distancePricingEnabled
    ? isGuest
      ? true
      : Boolean(serverCart?.delivery?.requiresLocation || cartGroups.some((group) => group.deliveryRequiresLocation))
    : false;
  const etaLabel = estimatedDeliveryMinutes
    ? t("checkout.summary.etaValue", { value: `${estimatedDeliveryMinutes} ${t("checkout.summary.minutes", "min")}` })
    : t("checkout.summary.etaValue", { value: "30-45 min" });
  const couponNotice = !isGuest ? serverCart?.couponNotice : null;
  const couponNoticeText = extractNoticeMessage(couponNotice);
  const loyaltyNotices = useMemo(() => {
    if (!loyaltyEnabled) return [];
    const notes: string[] = [];
    if (maxRedeemablePoints > 0) {
      notes.push(
        t("checkout.loyalty.maxPerOrder", {
          value: maxRedeemablePoints,
          defaultValue: `You can redeem up to ${maxRedeemablePoints} points for this order.`,
        })
      );
    }
    if (loyaltySettings?.minRedeemPoints) {
      notes.push(
        t("checkout.loyalty.minRedeem", {
          value: loyaltySettings.minRedeemPoints,
          defaultValue: `Minimum ${loyaltySettings.minRedeemPoints} points to redeem.`,
        })
      );
    }
    if (loyaltySettings?.maxDiscountPercent) {
      notes.push(
        t("checkout.loyalty.maxDiscountPercent", {
          value: loyaltySettings.maxDiscountPercent,
          defaultValue: `Loyalty discount capped at ${loyaltySettings.maxDiscountPercent}% of order total.`,
        })
      );
    }
    return notes;
  }, [loyaltyEnabled, maxRedeemablePoints, loyaltySettings, t]);

  const debouncedGuestAddress = useDebouncedValue(guestAddress, 350);
  const debouncedGuestLat = useDebouncedValue(guestLatInput, 350);
  const debouncedGuestLng = useDebouncedValue(guestLngInput, 350);

  const checkoutSteps = isGuest
    ? distancePricingEnabled
      ? [
          t("checkout.steps.cart", "Cart"),
          t("checkout.steps.guest", "Details"),
          t("checkout.steps.location", "Location"),
          t("checkout.steps.confirm", "Confirm"),
        ]
      : [
          t("checkout.steps.cart", "Cart"),
          t("checkout.steps.guest", "Details"),
          t("checkout.steps.confirm", "Confirm"),
        ]
    : [
        t("checkout.steps.cart", "Cart"),
        t("checkout.steps.address", "Address"),
        t("checkout.steps.summary", "Summary"),
        t("checkout.steps.confirm", "Confirm"),
      ];

  useEffect(() => {
    if (isGuest) return;
    if (!selectedAddressId && addresses.length > 0) {
      setSelectedAddressId(addresses[0].id);
    }
  }, [addresses, selectedAddressId, isGuest]);

  useEffect(() => {
    if (isGuest) {
      setLoyaltyToRedeem(0);
      return;
    }
    setLoyaltyToRedeem((prev) => Math.min(prev, maxRedeemablePoints));
  }, [maxRedeemablePoints, isGuest]);

  useEffect(() => {
    if (previewItems.length) {
      trackCheckoutStarted(cartId || "cart");
    }
  }, [previewItems.length, cartId]);

  useEffect(() => {
    if (!isGuest) return;
    updateAppState({
      guestSession: {
        name: guestName.trim() || undefined,
        phone: guestPhone.trim() || undefined,
        address: {
          fullAddress: guestAddress.trim() || undefined,
          lat: guestLat ?? undefined,
          lng: guestLng ?? undefined,
          notes: guestAddressNotes.trim() || undefined,
        },
      },
    });
  }, [
    isGuest,
    guestName,
    guestPhone,
    guestAddress,
    guestLat,
    guestLng,
    guestAddressNotes,
    updateAppState,
  ]);

  useEffect(() => {
    if (!isGuest || !guestCheckoutEnabled) return;
    if (!guestItems.length) {
      setGuestQuote(null);
      setGuestQuoteError(null);
      return;
    }
    const addressValue = debouncedGuestAddress.trim();
    const lat = parseCoordinate(debouncedGuestLat ?? "");
    const lng = parseCoordinate(debouncedGuestLng ?? "");
    if (!addressValue || (distancePricingEnabled && (lat == null || lng == null))) {
      setGuestQuote(null);
      setGuestQuoteError(null);
      return;
    }
    if (isOffline) return;

    const requestId = guestQuoteRef.current + 1;
    guestQuoteRef.current = requestId;
    setGuestQuoteLoading(true);
    setGuestQuoteError(null);
    const addressPayload: { fullAddress: string; lat?: number; lng?: number } = {
      fullAddress: addressValue,
    };
    if (lat != null) addressPayload.lat = lat;
    if (lng != null) addressPayload.lng = lng;

    quoteGuestOrder({
      items: guestItems,
      address: addressPayload,
    })
      .then((quote) => {
        if (guestQuoteRef.current !== requestId) return;
        setGuestQuote(quote);
      })
      .catch((error) => {
        if (guestQuoteRef.current !== requestId) return;
        setGuestQuote(null);
        setGuestQuoteError(mapApiErrorToMessage(error, "checkout.messages.quoteError"));
      })
      .finally(() => {
        if (guestQuoteRef.current === requestId) {
          setGuestQuoteLoading(false);
        }
      });
  }, [
    isGuest,
    guestCheckoutEnabled,
    guestItems,
    debouncedGuestAddress,
    debouncedGuestLat,
    debouncedGuestLng,
    distancePricingEnabled,
    isOffline,
  ]);

  const selectedAddress = useMemo(() => {
    if (isGuest) return null;
    return addresses.find((addr: Address) => addr.id === selectedAddressId) || null;
  }, [addresses, selectedAddressId, isGuest]);
  const locationMissing = isGuest
    ? !guestLocationValid
    : !selectedAddress || selectedAddress.lat == null || selectedAddress.lng == null;
  const showAddressWarning = isGuest
    ? (deliveryRequiresLocation && locationMissing) || !guestAddressValid
    : Boolean(
        appState.user &&
          (deliveryRequiresLocation ? locationMissing : !selectedAddress || !selectedAddress.zoneId)
      );
  const guestReady =
    guestCheckoutEnabled &&
    Boolean(guestName.trim()) &&
    Boolean(guestPhone.trim()) &&
    guestAddressValid &&
    guestLocationValid;
  const canPlaceOrder =
    previewItems.length > 0 &&
    !isOffline &&
    deliveryTermsAccepted &&
    (isGuest ? guestReady : Boolean(selectedAddressId && cartId));

  const isOrderGroupSummary = (value: any): value is OrderGroupSummary =>
    Boolean(value && typeof value === "object" && Array.isArray(value.orders) && value.orderGroupId);

  function ensureIdempotencyKey() {
    if (idempotencyKeyRef.current) return idempotencyKeyRef.current;
    const key =
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `checkout-${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
    idempotencyKeyRef.current = key;
    return key;
  }

  async function handleGuestOrder() {
    if (!deliveryTermsAccepted) {
      showToast({ type: "error", message: t("checkout.deliveryTerms.required", "Please accept the delivery terms.") });
      return;
    }
    if (!guestCheckoutEnabled) {
      showToast({ type: "error", message: t("checkout.guest.disabled", "Guest checkout is disabled.") });
      return;
    }
    if (!guestItems.length) {
      showToast({ type: "error", message: t("checkout.messages.emptyCart", "Your cart is empty.") });
      return;
    }
    const name = guestName.trim();
    const phone = guestPhone.trim();
    const fullAddress = guestAddress.trim();
    if (!name) {
      showToast({ type: "error", message: t("checkout.guest.nameRequired", "Name is required.") });
      return;
    }
    if (!phone) {
      showToast({ type: "error", message: t("checkout.guest.phoneRequired", "Phone is required.") });
      return;
    }
    if (!fullAddress) {
      showToast({ type: "error", message: t("checkout.guest.addressRequired", "Full address is required.") });
      return;
    }
    if (distancePricingEnabled && (!guestLocationValid || guestLat == null || guestLng == null)) {
      showToast({ type: "error", message: t("checkout.messages.missingLocation", "Location is required for delivery.") });
      return;
    }
    if (isOffline) {
      showToast({ type: "error", message: t("checkout.messages.offline", "You are offline. Please reconnect.") });
      return;
    }
    const idempotencyKey = ensureIdempotencyKey();
    savingRef.current = true;
    setSaving(true);
    try {
      const note = deliveryNotes.trim();
      const addressPayload: { fullAddress: string; lat?: number; lng?: number; notes?: string } = {
        fullAddress,
        notes: guestAddressNotes.trim() || undefined,
      };
      if (guestLat != null) addressPayload.lat = guestLat;
      if (guestLng != null) addressPayload.lng = guestLng;

      const res = await placeGuestOrder({
        name,
        phone,
        deliveryTermsAccepted,
        note: note ? note : undefined,
        idempotencyKey,
        items: guestItems,
        address: addressPayload,
      });
      cart.clearLocal();
      const isGroup = isOrderGroupSummary(res);
      const detailOrder = !isGroup ? (res as OrderDetail) : null;
      const trackingCode = isGroup
        ? (res as OrderGroupSummary).code ?? (res as OrderGroupSummary).orderGroupId
        : detailOrder?.code ?? detailOrder?.id ?? null;
      idempotencyKeyRef.current = null;
      updateAppState((prev) => ({
        ...prev,
        cart: [],
        lastOrder: res,
        lastOrderId: detailOrder ? detailOrder.id : (res as OrderGroupSummary).orderGroupId ?? null,
        selectedOrder: res,
        selectedOrderId: detailOrder ? detailOrder.id : null,
        selectedOrderSummary: detailOrder
          ? {
              id: detailOrder.id,
              totalCents: detailOrder.totalCents,
              status: detailOrder.status,
              createdAt: detailOrder.createdAt,
            }
          : null,
        guestTracking: { phone, code: trackingCode ?? undefined },
        currentScreen: "order-success",
      }));
      trackOrderPlaced(trackingCode ?? "guest-order", res.totalCents);
    } catch (error: any) {
      const friendly = apiErrorToast(error, "checkout.messages.submitError");
      trackOrderFailed(friendly);
      idempotencyKeyRef.current = null;
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  }

  async function handlePlaceOrder() {
    if (savingRef.current) return;
    if (!deliveryTermsAccepted) {
      showToast({ type: "error", message: t("checkout.deliveryTerms.required", "Please accept the delivery terms.") });
      return;
    }
    if (isGuest) {
      await handleGuestOrder();
      return;
    }
    let finalCartId: string | null = cartId;
    if (!finalCartId) {
      try {
        const refreshed = await cart.refetch();
        finalCartId = refreshed?.cartId ?? cart.rawCart?.cartId ?? null;
      } catch {
        finalCartId = null;
      }
    }
    if (!finalCartId) {
      showToast({ type: "error", message: t("checkout.messages.missingCart", "Your cart is not available.") });
      return;
    }
    if (!selectedAddressId) {
      showToast({ type: "error", message: t("checkout.messages.missingAddress") });
      return;
    }
    if (deliveryRequiresLocation && locationMissing) {
      showToast({ type: "error", message: t("checkout.messages.missingLocation", "Location is required for delivery.") });
      return;
    }
    if (!deliveryRequiresLocation && !selectedAddress?.zoneId) {
      showToast({ type: "error", message: t("checkout.messages.missingZone") });
      return;
    }
    if (isOffline) {
      showToast({ type: "error", message: t("checkout.messages.offline", "You are offline. Please reconnect.") });
      return;
    }
    const idempotencyKey = ensureIdempotencyKey();
    savingRef.current = true;
    setSaving(true);
    try {
      const note = deliveryNotes.trim();
      const res = await placeOrder({
        addressId: selectedAddressId,
        paymentMethod: "COD",
        deliveryTermsAccepted,
        note: note ? note : undefined,
        couponCode: appliedCoupon || undefined,
        loyaltyPointsToRedeem: loyaltyEnabled && loyaltyToRedeem > 0 ? loyaltyToRedeem : undefined,
        idempotencyKey,
      });
      await cart.refetch();
      const isGroup = isOrderGroupSummary(res);
      let orderId = "";
      let detailOrder: OrderDetail | null = null;
      if (isGroup) {
        orderId = res.orderGroupId;
      } else {
        orderId = res.id;
        detailOrder = res as OrderDetail;
      }
      const redeemedPoints = isGroup
        ? 0
        : detailOrder?.loyaltyPointsRedeemed ?? (loyaltyEnabled ? loyaltyToRedeem : 0);
      const earnedPoints = isGroup ? 0 : detailOrder?.loyaltyPointsEarned ?? 0;
      setLoyaltyToRedeem(0);
      idempotencyKeyRef.current = null;
      updateAppState((prev) => ({
        ...prev,
        user: prev.user
          ? {
              ...prev.user,
              loyaltyPoints: Math.max(
                0,
                (prev.user.loyaltyPoints ?? prev.user.points ?? 0) - redeemedPoints + earnedPoints
              ),
              points: Math.max(
                0,
                (prev.user.points ?? prev.user.loyaltyPoints ?? 0) - redeemedPoints + earnedPoints
              ),
            }
          : prev.user,
        cart: [],
        lastOrder: res,
        lastOrderId: detailOrder ? detailOrder.id : null,
        selectedOrder: res,
        selectedOrderId: detailOrder ? detailOrder.id : null,
        selectedOrderSummary: detailOrder
          ? {
              id: detailOrder.id,
              totalCents: detailOrder.totalCents,
              status: detailOrder.status,
              createdAt: detailOrder.createdAt,
            }
          : null,
        currentScreen: "order-success",
      }));
      trackOrderPlaced(orderId, res.totalCents);
    } catch (error: any) {
      const friendly = apiErrorToast(error, "checkout.messages.submitError");
      trackOrderFailed(friendly);
      idempotencyKeyRef.current = null;
    } finally {
      savingRef.current = false;
      setSaving(false);
    }
  }

  async function handleApplyCoupon() {
    if (isGuest) {
      setCouponFeedback({ type: "error", message: t("checkout.coupon.guest", "Coupons are only for registered users.") });
      return;
    }
    if (!couponsEnabled) {
      setCouponFeedback({ type: "error", message: t("checkout.coupon.disabled", "Coupons are disabled.") });
      return;
    }
    const code = couponInput.trim();
    if (!code) {
      setCouponFeedback({ type: "error", message: t("checkout.coupon.required", "Enter a coupon code first.") });
      return;
    }
    setCouponFeedback(null);
    try {
      await cart.applyCoupon(code);
      setCouponFeedback({
        type: "success",
        message: t("checkout.coupon.applied", { code, defaultValue: `Coupon ${code} applied.` }),
      });
    } catch (error: any) {
      const message = mapApiErrorToMessage(error, "checkout.coupon.error");
      setCouponFeedback({ type: "error", message });
    }
  }

  const handleUseCurrentLocation = () => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      showToast({
        type: "error",
        message: t("checkout.guest.locationUnavailable", "Location services are not available."),
      });
      return;
    }
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setGuestLatInput(pos.coords.latitude.toFixed(6));
        setGuestLngInput(pos.coords.longitude.toFixed(6));
        showToast({
          type: "success",
          message: t("checkout.guest.locationSet", "Location updated."),
        });
      },
      () => {
        showToast({
          type: "error",
          message: t("checkout.guest.locationError", "Unable to get your location."),
        });
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  };

  const renderAddress = (address: Address) => {
    const lang = i18n.language?.startsWith("ar") ? "ar" : "en";
    const zoneName = address.deliveryZone
      ? (lang === "ar" ? address.deliveryZone.nameAr || address.deliveryZone.nameEn : address.deliveryZone.nameEn || address.deliveryZone.nameAr)
      : address.zone;
    const line1 = [address.city, zoneName].filter(Boolean).join(", ");
    const line2 = [address.street, address.building, address.apartment].filter(Boolean).join(", ");
    const zoneSummary = address.deliveryZone
      ? [
          fmtEGP(fromCents(address.deliveryZone.feeCents)),
          address.deliveryZone.etaMinutes
            ? t("addresses.zoneEta", { value: address.deliveryZone.etaMinutes })
            : null,
        ]
          .filter(Boolean)
          .join(" • ")
      : null;
    const isSelected = selectedAddressId === address.id;

    return (
      <button
        key={address.id}
        onClick={() => setSelectedAddressId(address.id)}
        className={`w-full text-left rounded-xl border p-4 transition ${
          isSelected ? "border-primary bg-primary/5" : "border-gray-200 bg-white"
        }`}
      >
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <MapPin className="w-4 h-4 text-primary" />
            <p className="font-semibold text-gray-900">{address.label || t("checkout.address.defaultName")}</p>
            {address.isDefault && (
              <Badge variant="secondary" className="text-xs">
                {t("addresses.badges.default", "Default")}
              </Badge>
            )}
          </div>
          {isSelected && <Badge>{t("checkout.address.selected", "Selected")}</Badge>}
        </div>
        <p className="text-sm text-gray-700">{line1 || t("checkout.address.noCity")}</p>
        {line2 && <p className="text-xs text-gray-500 mt-1">{line2}</p>}
        {zoneSummary && <p className="text-xs text-gray-500 mt-1">{zoneSummary}</p>}
      </button>
    );
  };

  const renderItems = () => {
    if (loading) {
      return (
        <div className="space-y-3">
          {Array.from({ length: 3 }).map((_, idx) => (
            <div key={idx} className="bg-white rounded-xl p-3 shadow-sm flex gap-3 border border-border">
              <Skeleton className="w-16 h-16 rounded-lg skeleton-soft" />
              <div className="flex-1 space-y-2">
                <Skeleton className="h-4 w-2/3 skeleton-soft" />
                <Skeleton className="h-4 w-1/3 skeleton-soft" />
              </div>
            </div>
          ))}
        </div>
      );
    }

    if (!previewItems.length) {
      return (
        <div className="bg-white rounded-xl p-6 text-center text-gray-500">
          {t("checkout.messages.emptyCart", "Your cart is empty. Add items to checkout.")}
        </div>
      );
    }

    return (
      <div className="space-y-3">
        {previewItems.map((item) => {
          const price = item.price;
          return (
            <div key={item.id} className="bg-white rounded-xl p-3 shadow-sm flex gap-3 border border-border">
              <div className="w-16 h-16 rounded-lg overflow-hidden bg-gray-100">
                {item.image ? (
                  <ImageWithFallback src={item.image} alt={item.name ?? ""} className="w-full h-full object-cover" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-400 text-xl">Cart</div>
                )}
              </div>
              <div className="flex-1">
                <p className="font-medium text-gray-900">{item.name || item.product?.name || t("checkout.item.unknown")}</p>
                <p className="text-sm text-gray-500">
                  {item.quantity} x {fmtEGP(price)}
                </p>
              </div>
              <div className="font-semibold text-gray-900">{fmtEGP(price * item.quantity)}</div>
            </div>
          );
        })}
      </div>
    );
  };

  if (hasError) {
    return (
      <div className="page-shell">
        <NetworkBanner />
        <RetryBlock
          message={errorMessage || t("checkout.messages.loadError")}
          onRetry={() => {
            cart.refetch();
            refetchAddresses();
          }}
        />
      </div>
    );
  }

  return (
    <div className="page-shell">
      <NetworkBanner />
      <div className="section-card flex items-center justify-between">
        <div className="flex items-center">
          <Button variant="ghost" size="sm" onClick={() => goToCart(updateAppState)} className="p-2 mr-2 rounded-full">
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="font-poppins text-xl text-gray-900" style={{ fontWeight: 600 }}>
              {t("checkout.title")}
            </h1>
            <p className="text-xs text-gray-500">{t("checkout.subtitle", { count: previewItems.length })}</p>
          </div>
        </div>
        {!isGuest && (
          <Button size="sm" variant="outline" onClick={() => updateAppState({ currentScreen: "addresses" })} className="rounded-xl">
            <Plus className="w-4 h-4 mr-1" />
            {t("checkout.address.add")}
          </Button>
        )}
      </div>

      <div className="section-card glass-surface space-y-2">
        <p className="text-xs text-gray-500">
          {isGuest
            ? t("checkout.stepsLabelGuest", "Cart > Details > Location > Confirm")
            : t("checkout.stepsLabel", "Cart > Address > Summary > Confirm")}
        </p>
        <div className="flex items-center gap-3 text-sm font-semibold text-gray-900">
          {checkoutSteps.map((label, idx) => (
            <div key={label} className="flex items-center gap-2 flex-1">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white ${idx <= 2 ? "bg-primary" : "bg-gray-300"}`}>
                {idx + 1}
              </div>
              <span className="text-xs sm:text-sm">{label}</span>
              {idx < checkoutSteps.length - 1 && <div className="flex-1 h-px bg-gray-200" />}
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 overflow-y-auto space-y-4 pb-24 w-full">
        <section className="section-card space-y-3">
          <h2 className="font-semibold text-gray-900 mb-3">{t("checkout.sections.items")}</h2>
          {renderItems()}
        </section>

        {!isGuest ? (
          <section className="section-card space-y-3">
            <h2 className="font-semibold text-gray-900 mb-3">{t("checkout.sections.address")}</h2>
            {addresses.length === 0 && !loading ? (
              <EmptyState
                icon={<MapPin className="w-10 h-10 text-primary" />}
                title={t("checkout.address.empty", "No saved addresses yet. Add one to continue.")}
                subtitle={t("checkout.address.subtitle", "Create an address to place your order.")}
                actionLabel={t("checkout.address.add")}
                onAction={() => updateAppState({ currentScreen: "addresses" })}
              />
            ) : (
              <div className="space-y-3">{addresses.map(renderAddress)}</div>
            )}
          </section>
        ) : (
          <>
            <section className="section-card space-y-3">
              <h2 className="font-semibold text-gray-900 mb-3">
                {t("checkout.guest.detailsTitle", "Guest details")}
              </h2>
              {!guestCheckoutEnabled && (
                <div className="bg-amber-50 text-amber-900 text-sm rounded-xl p-3 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  {t("checkout.guest.disabled", "Guest checkout is disabled. Please sign in to continue.")}
                </div>
              )}
              <div className="space-y-3">
                <div>
                  <Label>{t("checkout.guest.nameLabel", "Full name")}</Label>
                  <Input
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder={t("checkout.guest.namePlaceholder", "Enter your name")}
                    className="mt-1"
                  />
                </div>
                <div>
                  <Label>{t("checkout.guest.phoneLabel", "Phone number")}</Label>
                  <Input
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    placeholder={t("checkout.guest.phonePlaceholder", "Enter your phone")}
                    className="mt-1"
                  />
                </div>
                <p className="text-xs text-gray-500">
                  {t("checkout.guest.phoneHint", "We will use your phone to send order updates and tracking.")}
                </p>
              </div>
            </section>
            <section className="section-card space-y-3">
              <h2 className="font-semibold text-gray-900 mb-3">
                {t("checkout.guest.addressTitle", "Delivery address")}
              </h2>
              <div className="space-y-3">
                <div>
                  <Label>{t("checkout.guest.fullAddress", "Full address")}</Label>
                  <Textarea
                    placeholder={t("checkout.guest.addressPlaceholder", "Street, building, area")}
                    value={guestAddress}
                    onChange={(e) => setGuestAddress(e.target.value)}
                    className="min-h-[80px]"
                  />
                </div>
                {distancePricingEnabled && (
                  <>
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <Label>{t("checkout.guest.locationTitle", "Location")}</Label>
                        <Button variant="outline" size="sm" onClick={handleUseCurrentLocation} className="rounded-xl">
                          <MapPin className="w-4 h-4 mr-1" />
                          {t("checkout.guest.useLocation", "Use current location")}
                        </Button>
                      </div>
                      <LocationPicker
                        value={guestLocationValue}
                        onChange={handleGuestLocationPick}
                        placeholder={t("checkout.guest.locationHint", "Tap the map to drop a pin")}
                        active
                      />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <Label>{t("checkout.guest.latLabel", "Latitude")}</Label>
                        <Input
                          type="number"
                          step="0.000001"
                          value={guestLatInput}
                          onChange={(e) => setGuestLatInput(e.target.value)}
                          placeholder="30.123456"
                        />
                      </div>
                      <div>
                        <Label>{t("checkout.guest.lngLabel", "Longitude")}</Label>
                        <Input
                          type="number"
                          step="0.000001"
                          value={guestLngInput}
                          onChange={(e) => setGuestLngInput(e.target.value)}
                          placeholder="31.123456"
                        />
                      </div>
                    </div>
                  </>
                )}
                <div>
                  <Label>{t("checkout.guest.notesLabel", "Address notes")}</Label>
                  <Textarea
                    placeholder={t("checkout.guest.notesPlaceholder", "Apartment, landmark, delivery notes")}
                    value={guestAddressNotes}
                    onChange={(e) => setGuestAddressNotes(e.target.value)}
                    className="min-h-[70px]"
                  />
                </div>
                {guestQuoteLoading && (
                  <div className="text-xs text-gray-500">{t("checkout.guest.quoteLoading", "Calculating delivery...")}</div>
                )}
                {guestQuoteError && (
                  <div className="text-xs text-red-600 bg-red-50 rounded-xl p-2">{guestQuoteError}</div>
                )}
                {guestQuote?.skippedBranchIds && guestQuote.skippedBranchIds.length > 0 && (
                  <div className="text-xs text-amber-700 bg-amber-50 rounded-xl p-2">
                    {t("checkout.guest.skippedBranches", "Some items are unavailable and were skipped.")}
                  </div>
                )}
              </div>
            </section>
          </>
        )}

        <section className="section-card space-y-3">
          <h2 className="font-semibold text-gray-900 mb-3">{t("checkout.sections.payment")}</h2>
          <div className="inline-card flex items-center gap-3">
            <DollarSign className="w-5 h-5 text-primary" />
            <div>
              <p className="font-semibold text-gray-900">{t("checkout.payment.codOnly", "Cash on delivery")}</p>
              <p className="text-sm text-gray-600">
                {t("checkout.payment.codOnlyDesc", "Only cash payments are supported at the moment.")}
              </p>
            </div>
          </div>
        </section>

        {loyaltyEnabled && (
          <section className="section-card space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-gray-900">{t("checkout.loyalty.title")}</h2>
              <Button variant="ghost" size="sm" onClick={() => setLoyaltyToRedeem(maxRedeemablePoints)}>
                {t("checkout.loyalty.useMax")}
              </Button>
            </div>
            <div>
              <Label>{t("checkout.loyalty.pointsLabel")}</Label>
              <Input
                type="number"
                min={0}
                max={maxRedeemablePoints}
                value={loyaltyToRedeem}
                onChange={(e) => {
                  const next = Number(e.target.value);
                  if (Number.isNaN(next)) {
                    setLoyaltyToRedeem(0);
                    return;
                  }
                  setLoyaltyToRedeem(Math.max(0, Math.min(maxRedeemablePoints, next)));
                }}
                disabled={isOffline}
                className="mt-1"
              />
            </div>
            <p className="text-xs text-gray-500">
              {t("checkout.loyalty.balance", { balance: loyaltyBalance })}
            </p>
            {previewRedeemValue > 0 && (
              <p className="text-xs text-green-600">
                {t("checkout.loyalty.preview", { amount: fmtEGP(previewRedeemValue) })}
              </p>
            )}
            {loyaltyNotices.length > 0 && (
              <ul className="text-xs text-gray-500 space-y-1 list-disc list-inside">
                {loyaltyNotices.map((notice) => (
                  <li key={notice}>{notice}</li>
                ))}
              </ul>
            )}
          </section>
        )}

        {!isGuest && couponsEnabled && (
          <section className="section-card space-y-3">
            <h3 className="font-semibold text-gray-900">{t("checkout.coupon.title", "Coupon")}</h3>
            <div className="flex flex-col gap-2 sm:flex-row">
              <Input
                value={couponInput}
                onChange={(e) => setCouponInput(e.target.value)}
                placeholder={t("checkout.coupon.placeholder", "Enter coupon code")}
                className="flex-1"
                disabled={cart.applyingCoupon}
              />
              <Button
                type="button"
                onClick={handleApplyCoupon}
                disabled={cart.applyingCoupon}
                className="h-11 rounded-xl sm:w-32"
              >
                {cart.applyingCoupon ? t("checkout.coupon.applying", "Applying...") : t("checkout.coupon.apply", "Apply")}
              </Button>
            </div>
            {appliedCoupon && (
              <p className="text-xs text-gray-500">{t("checkout.coupon.appliedLabel", { code: appliedCoupon, defaultValue: `Applied coupon: ${appliedCoupon}` })}</p>
            )}
            {couponFeedback && (
              <p className={`text-sm ${couponFeedback.type === "success" ? "text-green-600" : "text-red-600"}`}>{couponFeedback.message}</p>
            )}
            {couponNoticeText && (
              <div className="bg-amber-50 text-amber-900 text-xs rounded-xl p-2 border border-amber-100">
                {couponNoticeText}
              </div>
            )}
          </section>
        )}

        <section className="section-card space-y-3">
          <h3 className="font-semibold text-gray-900">{t("checkout.sections.notes")}</h3>
          <Textarea
            placeholder={t("checkout.notes.placeholder")}
            value={deliveryNotes}
            onChange={(e) => setDeliveryNotes(e.target.value)}
            className="min-h-[80px]"
          />
        </section>

        <section className="section-card space-y-3">
          <h3 className="font-semibold text-gray-900">{t("checkout.sections.summary")}</h3>
          {showAddressWarning && (
            <div className="bg-amber-50 text-amber-900 text-sm rounded-xl p-2 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4" />
              <span>
                {isGuest
                  ? t("checkout.guest.addressRequired", "Enter full address and location to continue.")
                  : deliveryRequiresLocation
                    ? t("checkout.messages.missingLocation", "Location is required for delivery.")
                    : t("checkout.messages.missingZone")}
              </span>
            </div>
          )}
          {isGuest && (
            <div className="bg-gray-50 text-gray-700 text-xs rounded-xl p-2">
              {t("checkout.guest.noRewards", "Guest orders do not use coupons or loyalty rewards.")}
            </div>
          )}
          <div className="flex items-center justify-between text-sm text-gray-600">
            <span>{t("checkout.summary.subtotal")}</span>
            <span className="price-text">{fmtEGP(subtotal)}</span>
          </div>
          <div className="flex items-center justify-between text-sm text-gray-600">
            <span className="flex items-center gap-1">
              <Truck className="w-4 h-4" />
              {t("checkout.summary.delivery")}
            </span>
            <span className="price-text">{shippingFee ? fmtEGP(shippingFee) : t("checkout.summary.freeDelivery", "Free")}</span>
          </div>
          <div className="flex items-center justify-between text-sm text-gray-600">
            <span>{t("checkout.summary.serviceFee", "Service fee")}</span>
            <span className="price-text">{fmtEGP(serviceFee)}</span>
          </div>
          {cartGroups.length > 0 && (
            <div className="rounded-xl bg-gray-50 p-3 text-xs text-gray-600 space-y-2">
              <p className="font-semibold text-gray-900">
                {t("checkout.summary.byBranch", "Delivery by branch")}
              </p>
              {cartGroups.map((group) => {
                const branchName =
                  i18n.language?.startsWith("ar")
                    ? group.branchNameAr || group.branchName || group.branchId
                    : group.branchName || group.branchNameAr || group.branchId;
                const feeLabel = group.deliveryUnavailable
                  ? t("checkout.summary.deliveryUnavailable", "Unavailable")
                  : fmtEGP(fromCents(group.shippingFeeCents ?? 0));
                return (
                  <div key={group.branchId} className="flex items-center justify-between">
                    <span className="text-gray-700">{branchName}</span>
                    <span className="font-medium text-gray-900">{feeLabel}</span>
                  </div>
                );
              })}
            </div>
          )}
          <div className="flex items-center justify-between text-sm text-gray-600">
            <span className="flex items-center gap-1">
              <Clock className="w-4 h-4" />
              {t("checkout.summary.eta")}
            </span>
            <span>
              {isGuest
                ? guestLocationValid
                  ? etaLabel
                  : t("checkout.summary.etaUnknown")
                : selectedAddress
                  ? etaLabel
                  : t("checkout.summary.etaUnknown")}
            </span>
          </div>
          {couponDiscount > 0 && (
            <div className="flex items-center justify-between text-sm text-green-600">
              <span>{t("checkout.summary.discount", "Discount")}</span>
              <span className="price-text">-{fmtEGP(couponDiscount)}</span>
            </div>
          )}
          {(loyaltyDiscount > 0 || previewRedeemValue > 0) && (
            <div className="flex items-center justify-between text-sm text-green-600">
              <span>{t("checkout.loyalty.summaryLabel")}</span>
              <span className="price-text">-{fmtEGP(loyaltyDiscount + previewRedeemValue)}</span>
            </div>
          )}
          <div className="flex items-center justify-between text-lg font-semibold text-gray-900">
            <span>{t("checkout.summary.total")}</span>
            <span className="price-text">{fmtEGP(total)}</span>
          </div>
          <label className="flex items-start gap-3 rounded-xl border border-gray-200 bg-white p-3 text-xs text-gray-700">
            <input
              type="checkbox"
              className="mt-1 h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
              checked={deliveryTermsAccepted}
              onChange={(e) => setDeliveryTermsAccepted(e.target.checked)}
            />
            <span>
              {t(
                "checkout.deliveryTerms.text",
                "For the safety of our delivery captain and vehicle, delivery is at the building entrance by default. If a safe place is available, the captain can go up to the apartment door when possible."
              )}
            </span>
          </label>
          <div className="rounded-xl bg-gray-50 p-3 text-sm text-gray-700">
            <p className="font-semibold text-gray-900">{t("checkout.trust.title", "We deliver anywhere inside Badr City")}</p>
            <p className="text-xs text-gray-600">
              {t("checkout.trust.support", "Support available on WhatsApp for updates.")}
            </p>
          </div>
          <Button
            className="w-full h-12 rounded-xl"
            onClick={handlePlaceOrder}
            disabled={saving || !canPlaceOrder}
          >
            {saving ? t("checkout.actions.placing") : t("checkout.actions.placeOrder")}
          </Button>
        </section>
      </div>
      {saving && (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-sm flex items-center justify-center z-40">
          <div className="bg-white rounded-xl px-6 py-4 shadow-xl text-center space-y-2">
            <p className="font-semibold text-gray-900">{t("checkout.actions.placing")}</p>
            <p className="text-sm text-gray-600">{t("checkout.messages.processing", "Please wait while we place your order...")}</p>
          </div>
        </div>
      )}
    </div>
  );
}







