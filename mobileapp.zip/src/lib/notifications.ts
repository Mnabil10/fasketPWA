export {
  initializePushNotifications as initPush,
  registerDeviceToken,
  subscribeToNotifications,
  handleIncomingNotification,
} from "../customer/utils/pushNotifications";

