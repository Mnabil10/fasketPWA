package customer.fasket.cloud;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
