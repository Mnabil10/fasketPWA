System.register(["./ionic-legacy-kwwgMU-Q.js","./react-legacy-B1-f77hp.js"],function(t,e){"use strict";var n,r,i;return{setters:[t=>{n=t.i,r=t.e,i=t.f},null],execute:function(){
/*!
             * (C) Ionic http://ionicframework.com - MIT License
             */
t("createSwipeBackGesture",(t,e,c,s,o)=>{const a=t.ownerDocument.defaultView;let l=n(t);const u=t=>l?-t.deltaX:t.deltaX;return r({el:t,gestureName:"goback-swipe",gesturePriority:101,threshold:10,canStart:r=>(l=n(t),(t=>{const{startX:e}=t;return l?e>=a.innerWidth-50:e<=50})(r)&&e()),onStart:c,onMove:t=>{const e=u(t)/a.innerWidth;s(e)},onEnd:t=>{const e=u(t),n=a.innerWidth,r=e/n,c=(t=>l?-t.velocityX:t.velocityX)(t),s=c>=0&&(c>.2||e>n/2),d=(s?1-r:r)*n;let h=0;if(d>5){const t=d/Math.abs(c);h=Math.min(t,540)}o(s,r<=0?.01:i(0,r,.9999),h)}})})}}});
