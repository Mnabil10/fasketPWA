import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: "customer.fasket.cloud",  
  appName: "Fasket",
  webDir: "dist"

};

export default config;
